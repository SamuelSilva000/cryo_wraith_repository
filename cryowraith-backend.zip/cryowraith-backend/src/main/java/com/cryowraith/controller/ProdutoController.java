package com.cryowraith.controller;

import com.cryowraith.model.Produto;
import com.cryowraith.repository.ProdutoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/produtos")
public class ProdutoController {

    private final ProdutoRepository produtoRepository;

    public ProdutoController(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    @GetMapping
    public List<Produto> listar() {
        return produtoRepository.findAll();
    }

    @GetMapping("/{nome}")
    public ResponseEntity<Produto> buscar(@PathVariable String nome) {
        return produtoRepository.findByNome(nome)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> salvar(@RequestBody Produto produto) {
        Optional<Produto> existente = produtoRepository.findByNome(produto.getNome());
        if (existente.isPresent()) {
            Produto p = existente.get();
            p.setPreco(produto.getPreco());
            p.setEstoque(produto.getEstoque());
            p.setDescricao(produto.getDescricao());
            p.setImagem(produto.getImagem());
            p.setTipo(produto.getTipo());
            p.setDestaque(produto.getDestaque());
            produtoRepository.save(p);
        } else {
            produto.setId(null);
            produtoRepository.save(produto);
        }
        return ResponseEntity.ok(Map.of("message", "ok"));
    }

    @DeleteMapping("/{nome}")
    public ResponseEntity<?> remover(@PathVariable String nome) {
        Produto p = produtoRepository.findByNome(nome).orElse(null);
        if (p != null) produtoRepository.delete(p);
        return ResponseEntity.ok(Map.of("message", "ok"));
    }
}