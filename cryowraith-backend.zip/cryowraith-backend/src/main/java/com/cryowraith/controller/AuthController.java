package com.cryowraith.controller;

import com.cryowraith.model.Usuario;
import com.cryowraith.repository.UsuarioRepository;
import com.cryowraith.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthController(UsuarioRepository usuarioRepository,
                          PasswordEncoder passwordEncoder,
                          JwtUtil jwtUtil) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registro(@RequestBody Map<String, String> body) {
        String nome = body.get("nome");
        String email = body.get("email");
        String senha = body.get("senha");

        if (nome == null || email == null || senha == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Campos obrigatórios"));
        }
        if (usuarioRepository.existsByEmail(email)) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email já cadastrado!"));
        }

        Usuario u = new Usuario();
        u.setNome(nome);
        u.setEmail(email);
        u.setSenha(passwordEncoder.encode(senha));
        u.setRole("user");
        usuarioRepository.save(u);

        return ResponseEntity.ok(Map.of("message", "ok"));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String senha = body.get("senha");

        Usuario u = usuarioRepository.findByEmail(email).orElse(null);
        if (u == null || !passwordEncoder.matches(senha, u.getSenha())) {
            return ResponseEntity.status(401).body(Map.of("message", "Credenciais inválidas"));
        }

        String token = jwtUtil.gerarToken(u.getEmail(), u.getRole());
        return ResponseEntity.ok(Map.of(
                "nome", u.getNome(),
                "email", u.getEmail(),
                "role", u.getRole(),
                "token", token
        ));
    }

    @GetMapping("/usuarios")
    public ResponseEntity<List<Usuario>> listarUsuarios() {
        return ResponseEntity.ok(usuarioRepository.findAll());
    }

    @PutMapping("/perfil")
    public ResponseEntity<?> atualizarPerfil(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String nome = body.get("nome");
        String senha = body.get("senha");

        Usuario u = usuarioRepository.findByEmail(email).orElse(null);
        if (u == null) return ResponseEntity.notFound().build();

        u.setNome(nome);
        if (senha != null && !senha.isEmpty()) {
            u.setSenha(passwordEncoder.encode(senha));
        }
        usuarioRepository.save(u);
        return ResponseEntity.ok(Map.of("message", "ok"));
    }
}