package com.cryowraith.controller;

import com.cryowraith.model.Pedido;
import com.cryowraith.model.Produto;
import com.cryowraith.repository.PedidoRepository;
import com.cryowraith.repository.ProdutoRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private final PedidoRepository pedidoRepository;
    private final ProdutoRepository produtoRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public PedidoController(PedidoRepository pedidoRepository,
                            ProdutoRepository produtoRepository) {
        this.pedidoRepository = pedidoRepository;
        this.produtoRepository = produtoRepository;
    }

    @GetMapping
    public List<Pedido> listar() {
        return pedidoRepository.findAll();
    }

    @GetMapping("/usuario/{email}")
    public List<Pedido> listarPorUsuario(@PathVariable String email) {
        return pedidoRepository.findByUserEmailOrderByDataDesc(email);
    }

    @PostMapping
    public ResponseEntity<?> criar(@RequestBody Pedido pedido) {
        // Atualizar estoque
        try {
            List<Map<String, Object>> itens = objectMapper.readValue(
                    pedido.getItens(), new TypeReference<>() {});
            for (Map<String, Object> item : itens) {
                String nomeCompleto = (String) item.get("nome");
                int qtd = (int) item.get("qtd");
                String nomeBase = nomeCompleto.split(" \\(Tam")[0];
                Produto p = produtoRepository.findByNome(nomeBase).orElse(null);
                if (p != null) {
                    p.setEstoque(Math.max(0, p.getEstoque() - qtd));
                    produtoRepository.save(p);
                }
            }
        } catch (Exception ignored) {}

        pedido.setStatus("Em preparação");
        Pedido salvo = pedidoRepository.save(pedido);
        return ResponseEntity.ok(salvo);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> atualizarStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Pedido p = pedidoRepository.findById(id).orElse(null);
        if (p == null) return ResponseEntity.notFound().build();
        p.setStatus(body.get("status"));
        pedidoRepository.save(p);
        return ResponseEntity.ok(p);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancelar(@PathVariable Long id) {
        pedidoRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "ok"));
    }
}